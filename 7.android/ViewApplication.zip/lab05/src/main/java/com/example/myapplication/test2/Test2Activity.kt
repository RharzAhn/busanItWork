package com.example.myapplication.test2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Test2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test2)
    }
}