package com.example.myapplication.ex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Ex1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ex1)
    }
}