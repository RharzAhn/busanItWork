package com.example.lab4.test03

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.lab4.R

class Test03Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test03)
    }
}